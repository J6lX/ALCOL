import React from "react";
import { Route, Routes, BrowserRouter as Router } from "react-router-dom";

import HomePage from "./components/home/HomePage";
import LoginPage from "./components/accounts/LoginPage";
// import RegisterPage from "./components/views/RegisterPage/RegisterPage";
import RegisterPage from "./components/accounts/RegisterPage";
import ModifyPage from "./components/accounts/ModifyPage";
import ModeSelectPage from "./components/battle/ModeSelectPage";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Button from "react-bootstrap/Button";
import "./App.css";
import profileImg from "./logo.svg";
import Mypage from "./components/mypage/Mypage";
// import Mypage from "./components/mypage/Mypage.js";

import "./App.css";

function LoginTag(props) {
  // isLogin === 로그인 상태 체크
  // 비로그인 상태의 네비게이션 바를 보려면 isLoggedin의 값을 false로 설정하세요.
  const isLoggedin = true;

  // 로그인 한 경우(isLoggedin === true인 경우) 회원 정보 표시
  if (isLoggedin) {
    return (
      <>
        <img
          src={profileImg}
          alt="프사"
          style={{
            width: 50,
            height: 50,
          }}></img>
        <Nav.Link className="signUpButton">동준이다</Nav.Link>
        <p
          href="#"
          style={{
            color: "#a0a0a0",
            fontSize: 15,
            marginRight: "50px",
          }}>
          로그아웃
        </p>
      </>
    );
    // 로그인 정보가 없는 경우 로그인 및 회원가입 버튼 표시
  } else {
    return (
      <>
        <Button className="loginButton" variant="warning">
          LOGIN
        </Button>
        <Nav.Link
          className="signUpButton"
          href="#action5"
          style={{
            color: "#979797",
            fontSize: 18,
          }}>
          Sign up
        </Nav.Link>
      </>
    );
  }
}

function App() {
  return (
    <div>
      {/* 네비게이션 바 */}
      <Navbar bg="dark" variant="dark" className="navbar">
        {/* 로고 표시 */}
        <Navbar.Brand href="#" className="logo">
          AlCol
        </Navbar.Brand>

        {/* 링크 표시(문제, 랭킹, 배틀) */}
        <Nav className="justify-content-center flex-grow-1 pe-3">
          <Nav.Link
            className="navContent"
            href="#action2"
            style={{
              color: "#e9e9e9",
            }}>
            Problem
          </Nav.Link>
          <Nav.Link
            className="navContent"
            href="#action3"
            style={{
              color: "#e9e9e9",
            }}>
            Ranking
          </Nav.Link>
          <Nav.Link
            className="navContent"
            href="#action4"
            style={{
              color: "#e9e9e9",
            }}>
            Battle
          </Nav.Link>
          {/* 이하 네비게이션 바 드롭다운 기능(더미 데이터) */}
          {/* <NavDropdown title="Dropdown">
                  <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
                  <NavDropdown.Item href="#action4">
                    Another action
                  </NavDropdown.Item>
                  <NavDropdown.Divider />
                  <NavDropdown.Item href="#action5">
                    Something else here
                  </NavDropdown.Item>
                </NavDropdown> */}
        </Nav>

        {/* 로그인 여부에 따라 로그인/회원가입 또는 프로필 표시 */}
        <LoginTag />

        {/* 네비게이션 바 끝 */}
      </Navbar>

      {/* 본문(임시) */}
      <div
        className="darkTheme"
        style={{
          backgroundColor: "#16171B",
        }}>
        {/* 본문 자리 임시용 데이터 */}
        {/* 마이페이지 콘텐츠만 넣으면 푸터 위에 흰 공간이 남지 않습니다. */}
        <h1>본문 들어갈 부분(임시)</h1>
        {/* 라우터 태그 목록 */}
        <Routes>
          <Route exact path="/" element={HomePage()} />

          <Route exact path="/login" element={LoginPage()} />
          <Route path="/mode" element={<ModeSelectPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/modify" element={<ModifyPage />} />
          <Route path="/mypage" exact={true} element={<Mypage />}></Route>

          {/* <Route exact path="/register" element={RegisterPage()} /> */}
        </Routes>
      </div>

      {/* 푸터 */}
      <footer className="footer">
        <h2 className="J6IX">J6IX</h2>
        <p className="textDark">이용약관</p>
        <p className="textDark">개인정보 처리방침</p>
        <p className="textDark">쿠키 설정</p>
      </footer>
    </div>
  );
}

export default App;
