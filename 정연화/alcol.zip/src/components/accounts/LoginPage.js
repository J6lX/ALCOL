import React from "react";
import { LockOutlined, MailOutlined } from "@ant-design/icons";
import { Button, Form, Input } from "antd";

function LoginPage() {
  // Login을 제출하면 실행되는 함수
  // 성공 시 localstorage에 토큰 발급
  // 아니면 에러 알림, 로그인 입력창 지워주기
  const onFinish = (values) => {
    console.log("Received values of form: ", values);
  };

  const fullmiddle = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "skyblue",
    width: "100%",
    height: "100vh",
  };

  const middle = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
  };

  const inputwidth = {
    width: "60%",
  };

  const loginbackground = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    width: "600px",
    border: "4px solid transparents",
    borderRadius: "10px",
  };

  const gradientline = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "linear-gradient(to right, red, orange)",
    width: "600px",
    borderRadius: "10px",
  };

  return (
    <div style={fullmiddle}>
      <div style={loginbackground}>
        <div style={gradientline}>
          <h1>로그인</h1>
          <Form
            style={middle}
            name="normal_login"
            className="login-form"
            initialValues={{ remember: true }}
            onFinish={onFinish}>
            <Form.Item
              name="email"
              rules={[{ required: true, message: "Please input your email!" }]}
              style={inputwidth}>
              <Input
                size="large"
                prefix={<MailOutlined className="site-form-item-icon" />}
                placeholder="이메일"
                type="email"
              />
            </Form.Item>
            <Form.Item
              name="password"
              rules={[{ required: true, message: "Please input your Password!" }]}
              style={inputwidth}>
              <Input
                size="large"
                prefix={<LockOutlined className="site-form-item-icon" />}
                type="password"
                placeholder="비밀번호"
              />
            </Form.Item>
            <a className="login-form-forgot" href="/">
              비밀번호를 잊으셨나요?
            </a>
            {/* <Form.Item>
              <Form.Item name="remember" valuePropName="checked" noStyle>
                <Checkbox>Remember me</Checkbox>
              </Form.Item>
            </Form.Item> */}

            <Form.Item>
              <Button type="primary" htmlType="submit" className="login-form-button">
                로그인
              </Button>
            </Form.Item>
            <Form.Item>
              <a href="/">회원가입</a>
            </Form.Item>
          </Form>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
